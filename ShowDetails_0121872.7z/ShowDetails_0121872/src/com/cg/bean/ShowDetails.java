package com.cg.bean;

import java.sql.Date;

public class ShowDetails {
	
	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int avSeats;
	private int priceTicket;
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public int getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(int priceTicket) {
		this.priceTicket = priceTicket;
	}
	
	public ShowDetails(String showId, String showName, String location,
			Date showDate, int avSeats, int priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avSeats = avSeats;
		this.priceTicket = priceTicket;
	}
	@Override
	public String toString() {
		return "ShowDetails [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avSeats=" + avSeats + ", priceTicket=" + priceTicket + "]";
	}
	public ShowDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((showId == null) ? 0 : showId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShowDetails other = (ShowDetails) obj;
		if (showId == null) {
			if (other.showId != null)
				return false;
		} else if (!showId.equals(other.showId))
			return false;
		return true;
	}
	
	

}
