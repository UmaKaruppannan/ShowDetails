package com.cg.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil
{
	
	
	public static Connection getConnection() throws SQLException
	{
		
		final String PROPFILE = "MyApplication.properties";
		
		Properties dbProperties;
		dbProperties = loadProperties(PROPFILE);
		
		
		// set the user name, password, driver type and network protocol
		
		OracleDataSource ods = new OracleDataSource();
		
		ods.setUser(dbProperties.getProperty("username"));
	    ods.setPassword(dbProperties.getProperty("password"));
	    ods.setDriverType(dbProperties.getProperty("drivertype"));
	    ods.setNetworkProtocol(dbProperties.getProperty("networkprotocol"));
	    ods.setURL(dbProperties.getProperty("url"));
	    return ods.getConnection();
	}

	private static Properties loadProperties(String fileName)
	{
		InputStream propsFile = null;
		Properties propertyFile = new Properties();
		
		try{
			propsFile = new FileInputStream(fileName);
			propertyFile.load(propsFile);
			propsFile.close();
		}
		catch(Exception e){
/*//			System.out.println("I/O Exception");
//			e.printStackTrace();
			
*/			//cant connect to database so termination application
			System.exit(1);
		}
	
	return propertyFile;
	
}
}

