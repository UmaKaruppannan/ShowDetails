package com.cg.service;

import java.util.List;

import com.cg.bean.ShowDetails;
import com.cg.dao.IShowDetailsDao;
import com.cg.dao.ShowDetailsDaoImpl;
import com.cg.exceptions.ShowDetailsException;

public class ShowServiceImpl implements IShowService 

{
	
private IShowDetailsDao showdao;
	
	public ShowServiceImpl()
	{
		showdao = new ShowDetailsDaoImpl();
	}
	

	@Override
	public int addShow(ShowDetails showDetails) throws ShowDetailsException {
	
		return showdao.addShow(showDetails);
	}

	@Override
	public List<ShowDetails> getShowDetails() throws ShowDetailsException {
		
		return showdao.getShowDetails();
	}

}
