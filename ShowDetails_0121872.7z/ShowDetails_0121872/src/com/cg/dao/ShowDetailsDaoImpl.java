package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.ShowDetails;
import com.cg.exceptions.ShowDetailsException;
import com.cg.util.DBUtil;

public class ShowDetailsDaoImpl implements IShowDetailsDao 


{
	public Logger myLogger;
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(ShowDetailsDaoImpl.class.getName());
	}


	@Override
	public int addShow(ShowDetails showDetails) throws ShowDetailsException 
	{
		int generatedID = -1;
		
		try(Connection con = DBUtil.getConnection())
		
	{
		
		String showId=showDetails.getShowId();
		
		
		
		
		String name = employee.getName();
		float salary = employee.getSalary();
		String dept = employee.getDepartment();
		String desg= employee.getDesignation();
		
		Statement stm = con.createStatement();	
		ResultSet res = stm.executeQuery("select empIdSeq.nextVal from dual");
		
		if(res.next()==false)
			throw new ShowDetailsException ("something went wrong while generation the query");
		
		int id = res.getInt(1);
		
		PreparedStatement pstm=
		con.prepareStatement("insert into Employee_U1 values (?,?,?,?,?)");
		
		pstm.setInt(1, id);
		pstm.setString(2, name);
		pstm.setString(3,dept);
		pstm.setString(4,desg);
		pstm.setFloat(5,salary);
		
		pstm.execute();
		generatedID =  id;
		
		myLogger.info("Employee Added Successfully");
		
	}

		
		catch(SQLException e)
	
		{
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new ShowDetailsException(e.getMessage());
		}
	
		catch (Exception e)

		{
			throw new ShowDetailsException(e.getMessage());	
		}
		return generatedID;
}	
		

		

		
	

	@Override
	public List<ShowDetails> getShowDetails() throws ShowDetailsException
	{
		
		return null;
	}


}