package com.cg.dao;

import java.util.List;




import com.cg.bean.ShowDetails;
import com.cg.exceptions.ShowDetailsException;

public interface IShowDetailsDao


{
	public int addShow(ShowDetails showDetails)throws ShowDetailsException;
	
	public List<ShowDetails> getShowDetails() throws  ShowDetailsException;

}
